To compile this code, put it onto the server, and in the terminal type in:
	gcc -o smallsh smallsh.c
I didn't see the thing just now about how the testscript is supposed to be run 
with the command "testscript 2>&1" but mine is just supposed to be run with the
command "testscript". Thank you!
	-Colleen